package com.example.yin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.yin.model.domain.ListSong;
import org.springframework.stereotype.Repository;

@Repository
public interface ListSongMapper extends BaseMapper<ListSong> {

}
