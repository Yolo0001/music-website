package com.example.yin.model.request;

import lombok.Data;

@Data
public class SongPlayRequest {

    private Integer songId;

    private Integer userId;
}












