package com.example.yin.model.request;

import lombok.Data;

@Data
public class SearchHistoryRequest {
    private Integer userId;
    private String keyword;
    private String searchType;
}








